module.exports = {
    name: 'accept',
    description: "accepts application",
    execute(message, args) {

            if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send("you dont' have permission to use this command")

            let User = message.mentions.users.first()
            if(!User) return message.channel.send("Please provide a user for me to accept")

        User.send({embed: {
                footer: {
                    icon_url: message.author.avatarURL(),
                    text: message.author.tag
                },
                title: "Application Accepted",
                description: ":tada: Your Partner application with " + message.guild.name + " got accepted by: " + message.author.tag + "\nAn Admin Will Message You Soon",
                color: '#50C878'
            }})

    }
}