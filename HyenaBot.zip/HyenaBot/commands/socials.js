module.exports = {
    name: 'socials',
    description: "socials",
    execute(msg, args){
        msg.channel.send({embed: {
                footer: {
                    icon_url: msg.author.avatarURL(),
                    text: msg.author.tag
                },
                fields: [
                    {
                        name: 'Youtube',
                        value: `[Main Channel](https://www.youtube.com/divinehyena)`
                    },
                    {
                        name: 'Youtube',
                        value: '[Second Channel](https://www.youtube.com/channel/UCr4xiCbOphN-HOuQqjMGXxQ)'
                    },
                    {
                        name: 'Youtube',
                        value: '[Lam Channel](https://www.youtube.com/channel/UCHY56GDKX1HvrBBinC3gFYA)'
                    },
                    {
                        name: 'Twitch',
                        value: '[Twitch Channel](https://www.twitch.tv/divinehyena1)'
                    },
                    {
                        name: 'Reddit',
                        value: '[Reddit Account](https://www.reddit.com/user/DivineHyena)'
                    }],
                color: '#50C878'
            }});
    }
}