module.exports = {
    name: "unban",
    description: "Unbans a member from the server",
    execute(message, args) {


        if (!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send("**You Dont Have The Permissions To Unban Someone! - [BAN_MEMBERS]**")

        if (!args[0]) return message.channel.send("**Please Enter A Name!**")

        let bannedMemberInfo = message.guild.fetchBans()

        let bannedMember = args.includes('<@!') ? args.replace('<@!', '').replace('>', '')
            : args.includes('<@') ? args.replace('<@', '').replace('<', '') : '';
        // if (!bannedMember) return message.channel.send("**Please Provide A Valid Username, Tag Or ID Or The User Is Not Banned!**")
        if (bannedMember === '') {
            message.reply('**Please Provide A Valid Username, Tag Or ID Or The User Is Not Banned!**');
            return;
        }

        message.guild.fetchBans().then(bans => {
            let member = bans.get(bannedMember);

            if (member == null) {
                message.reply('Cannot find a ban for the given user.');
            }
        })

        // let bannedMember = message.guild.fetchBans()
        //     .then(banned => {
        //         let list = banned.map(ban => ban.user.tag).join('\n');
        //     });

        let reason = args.slice(1).join(" ")

        if (!message.guild.me.hasPermission("BAN_MEMBERS")) return message.channel.send("**I Don't Have Permissions To Unban Someone! - [BAN_MEMBERS]**")
        try {
            if (reason) {
                message.guild.members.unban(bannedMember.user.id, reason)
                message.channel.send({embed: {
                        fields: [
                            {
                                name: 'User Unbanned',
                                value: `**${bannedMember.user.tag} has been unbanned for ${reason}**`
                            }],
                        color: "GREEN"
                    }})
            } else {
                message.guild.members.unban(bannedMember.user.id, reason)
                message.channel.send({embed: {
                        fields: [
                            {
                                name: 'User Unbanned',
                                value: `**${bannedMember.user.tag} has been unbanned**`
                            }],
                        color: "GREEN"
                    }})
            }
        } catch {
        }
    }
}