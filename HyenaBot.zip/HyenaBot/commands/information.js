module.exports = {
        name: 'information',
        description: "Information Sender",
        execute(msg, args){




            msg.channel.send({embed: {

                    footer: {
                        icon_url: client.user.avatarURL(),
                        text: client.user.tag
                    },
                    description: "**Rules -**\n" +
                        "😁 1. Be cool, kind, and civil. Treat all members with respect and express your thoughts in a constructive manner.\n" +
                        "👞 2. Use an appropriate name and avatar. Avoid special characters, emoji, obscenities, and impersonation. ( No alts from 3/25/21 forward )\n" +
                        "🗒️ 3. Do not spam. Avoid excessive messages, images, formatting, emoji, commands, and @mentions.\n" +
                        "🔕 4. Do not @mention or direct message mods. Respect them. They have lives too! DivineHyena and Glow have bravely opted out of this rule.\n" +
                        "🛡️ 5. No personal information. Protect your privacy and the privacy of others.\n" +
                        "🤕6. No harassment, abuse, or bullying.\n" +
                        "🗯️ 7. No racism, sexism, homophobia, or discriminatory speech, as well as swearing directed at people\n" +
                        "🏛️ 8.No political or religious topics. These complex subjects result in controversial and offensive posts.\n" +
                        "🚨 9. No piracy, sexual, NSFW, or otherwise suspicious content. We do not condone illegal or suspicious discussions and activity.\n" +
                        "🤔10. Rules are subject to common sense. These rules are not comprehensive and use of loopholes to violate the spirit of these rules is subject to enforcement.\n" +
                        "📜 11. Discord Terms of Service and Community Guidelines apply. You must be at least 13 years old to use Discord, and abide by all other terms and guidelines.\n" +
                        "\n" +
                        "**Information and FAQ's -**\n" +
                        "Q: *Whats your Minecraft Bedrock name?*\n" +
                        "A: Red Bull251\n" +
                        "\n" +
                        "Q: *Can I have moderator?*\n" +
                        "A: No, I only give it to people that I like and who have been here for a very long time that consistently tune into streams.\n" +
                        "\n" +
                        "    Q: *Can we collab?*\n" +
                        "A: If you have a fun video idea besides just playing regular Minecraft I will consider it! Your channel must be good and you have to be a well respected member in the Minecraft community.\n" +
                        "\n" +
                        "    Q: *Why am I getting pings about your videos?*\n" +
                        "A: I believe that if you are in this server that you are already subscribed and care enough that you want to be notified.\n" +
                        "\n" +
                        "    Q: *Region and device?*\n" +
                        "A: I play on Windows 10 on North American servers\n" +
                        "\n" +
                        "Q: *Computer, keyboard, mouse, etc*\n" +
                        "A: Computer: Ibuypower ( Honestly dont know the rest )\n" +
                        "Keyboard: Razer Cynosa Chroma\n" +
                        "Mouse: Razer Mamba Elite\n" +
                        "Mic: Razer Seiren X\n" +
                        "Headset: Some bad beats headphones\n" +
                        "Monitor: Some really old HP monitor since my nice one broke\n" +
                        "\n" +
                        "Q: *Who makes your thumbnails and edits your videos?*\n" +
                        "A: Glowstudent makes the minecraft render ( Minecraft Skin ) and i do the rest of the background and words. Who edits? I do. I learned all by myself.\n" +
                        "\n" +
                        "🎉**SCROLL UP FOR RULES!**",
                    color: '#50C878'
                }});
        }
    }