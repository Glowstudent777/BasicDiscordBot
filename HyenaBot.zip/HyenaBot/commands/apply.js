module.exports = {
    name: 'apply partner',
    description: "apply for partnership",
    execute(message, args) {

        if (args[0] === 'partner') {

            let command = args.toLocaleString()


            let questions = {
                firstQuestion: "Does You're Server Have a Nice Clean Design?",
                secondQuestion: "Link to Youtube Channel If You Have One (If not say Skip)",
                thirdQuestion: "Link To Discord",
                fourthQuestion: "Do You Have 50+ Discord Members?",
                fifthQuestion: "Is You're Community Active?",
            }

            message.channel.send("I have started this process in your DM's. Type `cancel` to cancel")
            message.author.send(questions.firstQuestion).then(msg => {
                const filter1 = m => m.author.id === message.author.id
                msg.channel.awaitMessages(filter1, {
                    time: 5 * 60000,
                    max: 1
                }).then(messages => {
                    let msg1 = messages.first().content
                    if (msg1.toLowerCase() === "cancel") return message.author.send("Ok, I have cancelled this process")
                    message.author.send(questions.secondQuestion).then(msg => {
                        const filter1 = m => m.author.id === message.author.id
                        msg.channel.awaitMessages(filter1, {
                            time: 5 * 60000,
                            max: 1
                        }).then(messages => {
                            let msg2 = messages.first().content
                            if (msg2.toLowerCase() === "cancel") return message.author.send("Ok, I have cancelled this process")
                            message.author.send(questions.thirdQuestion).then(msg => {
                                const filter1 = m => m.author.id === message.author.id
                                msg.channel.awaitMessages(filter1, {
                                    time: 5 * 60000,
                                    max: 1
                                }).then(messages => {
                                    let msg3 = messages.first().content
                                    if (msg3.toLowerCase() === "cancel") return message.author.send("Ok, I have cancelled this process")
                                    message.author.send(questions.fourthQuestion).then(msg => {
                                        const filter1 = m => m.author.id === message.author.id
                                        msg.channel.awaitMessages(filter1, {
                                            time: 5 * 60000,
                                            max: 1
                                        }).then(messages => {
                                            let msg4 = messages.first().content
                                            if (msg4.toLowerCase() === "cancel") return message.author.send("Ok, I have cancelled this process")
                                            message.author.send(questions.fifthQuestion).then(msg => {
                                                const filter1 = m => m.author.id === message.author.id
                                                msg.channel.awaitMessages(filter1, {
                                                    time: 5 * 60000,
                                                    max: 1
                                                }).then(messages => {

                                                    let msg5 = messages.first().content
                                                    if (msg5.toLowerCase() === "cancel") return message.author.send("Ok, I have cancelled this process")
                                                    message.author.send("Subbmitted application!").then(msg => {
                                                        let User = message.author.id;
                                                        message.client.channels.cache.get(applicationChannel).send({
                                                            embed: {
                                                                footer: {
                                                                    icon_url: message.author.avatarURL(),
                                                                    text: message.author.tag
                                                                },
                                                                title: "Application Submitted",
                                                                description: `This application was submitted by ${message.author.tag} (${message.author.id}).\nCreated: ${message.author.createdAt}`,
                                                                fields: [
                                                                    {
                                                                        name: `${questions.firstQuestion}`,
                                                                        value: "Answer: " + `${msg1}`
                                                                    },
                                                                    {
                                                                        name: `${questions.secondQuestion}`,
                                                                        value: "Answer: " + `${msg2}`
                                                                    },
                                                                    {
                                                                        name: `${questions.thirdQuestion}`,
                                                                        value: "Answer: " + `${msg3}`
                                                                    },
                                                                    {
                                                                        name: `${questions.fourthQuestion}`,
                                                                        value: "Answer: " + `${msg4}`
                                                                    },
                                                                    {
                                                                        name: `${questions.fifthQuestion}`,
                                                                        value: "Answer: " + `${msg5}`
                                                                    }],
                                                                color: '#50C878'
                                                            }
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                }
            }
}