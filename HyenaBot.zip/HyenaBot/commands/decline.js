module.exports = {
    name: 'decline',
    description: "declines application",
    execute(message, args) {

            if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send("you dont' have permission to use this command")

            let User = message.mentions.users.first()
            if(!User) return message.channel.send("Please provide a user for me to decline")

        User.send({embed: {
                footer: {
                    icon_url: message.author.avatarURL(),
                    text: message.author.tag
                },
                title: "Application Denied",
                description: "Your Partner application with " + message.guild.name + " got declined by: " + message.author.tag + "\nContinue to make your server even better! You can re-apply in 2 weeks!",
                color: '#e72222'
            }})

    }
}